<!DOCTYPE html>
<html>
<head>
    <title>Hotel Menu</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<header>
    <h1>🍴 sunsen Hotel</h1>

    <nav>
        <a href="index.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="order.php">Order</a>
    </nav>
</header>

<section class="menu">

    <h2>Our Menu</h2>

    <div class="food-container">

        <div class="food-card">
            <h3>🍛 Chicken Biryani</h3>
            <p>Delicious chicken biryani</p>
            <h4>₹180</h4>
            <button>Order Now</button>
        </div>

        <div class="food-card">
            <h3>🍚 Chicken Fried Rice</h3>
            <p>Fresh and tasty fried rice</p>
            <h4>₹160</h4>
            <button>Order Now</button>
        </div>

        <div class="food-card">
            <h3>🥘 Parotta</h3>
            <p>Soft and delicious parotta</p>
            <h4>₹50</h4>
            <button>Order Now</button>
        </div>

        <div class="food-card">
            <h3>🥗 Veg Meals</h3>
            <p>Traditional South Indian meals</p>
            <h4>₹120</h4>
            <button>Order Now</button>
        </div>

        <div class="food-card">
            <h3>🥤 Fresh Lime Juice</h3>
            <p>Refreshing fresh lime juice</p>
            <h4>₹60</h4>
            <button>Order Now</button>
        </div>

        <div class="food-card">
            <h3>🍦 Ice Cream</h3>
            <p>Delicious creamy ice cream</p>
            <h4>₹80</h4>
            <button>Order Now</button>
        </div>

    </div>

</section>

</body>
</html>