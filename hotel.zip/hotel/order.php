<!DOCTYPE html>
<html>
<head>
    <title>Place Order</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<header>
    <h1>🍴 sunsen Hotel</h1>

    <nav>
        <a href="index.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="order.php">Order</a>
    </nav>
</header>

<section class="order">

    <h2>Place Your Order</h2>

    <form onsubmit="showOrder(event)">

        <label>Customer Name</label>
        <input type="text" id="name" required>

        <label>Select Food</label>

        <select id="food">
            <option value="Chicken Biryani - ₹180">Chicken Biryani - ₹180</option>
            <option value="Chicken Fried Rice - ₹160">Chicken Fried Rice - ₹160</option>
            <option value="Parotta - ₹50">Parotta - ₹50</option>
            <option value="Veg Meals - ₹120">Veg Meals - ₹120</option>
            <option value="Fresh Lime Juice - ₹60">Fresh Lime Juice - ₹60</option>
            <option value="Ice Cream - ₹80">Ice Cream - ₹80</option>
        </select>

        <label>Quantity</label>
        <input type="number" id="quantity" min="1" value="1" required>

        <button type="submit">Place Order</button>

    </form>

    <div id="result"></div>

</section>

<script>

function showOrder(event) {

    event.preventDefault();

    let name = document.getElementById("name").value;
    let food = document.getElementById("food").value;
    let quantity = document.getElementById("quantity").value;

    document.getElementById("result").innerHTML =
        "<h3>✅ Order Confirmed!</h3>" +
        "<p><b>Customer:</b> " + name + "</p>" +
        "<p><b>Food:</b> " + food + "</p>" +
        "<p><b>Quantity:</b> " + quantity + "</p>" +
        "<p>Thank you for ordering! 🍽️</p>";
}

</script>

</body>
</html>