<!DOCTYPE html>
<html>
<head>
    <title>sunsen Hotel</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<header>
    <h1>🍴 sunsen Hotel</h1>

    <nav>
        <a href="index.php">Home</a>
        <a href="menu.php">Menu</a>
        <a href="order.php">Order</a>
    </nav>
</header>

<section class="hero">

    <h2>Welcome to sunsen Hotel</h2>

    <p>Delicious Food • Fresh Ingredients • Great Taste</p>

    <a href="menu.php">
        <button>View Menu</button>
    </a>

</section>

<section class="about">

    <h2>Our Speciality</h2>

    <p>
        Enjoy delicious and freshly prepared food
        with your family and friends.
    </p>

</section>

</body>
</html>